package com.zybooks.weightloss;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.List;

public class WeightActivity extends AppCompatActivity {

    EditText editTextWeight;
    Button buttonSubmitWeight;
    TextView textViewHistory;
    DatabaseHelper dbHelper;
    String currentUsername = "user"; // TODO: Replace this with actual logged-in username

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        // Initialize views
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonSubmitWeight = findViewById(R.id.buttonSubmitWeight);
        textViewHistory = findViewById(R.id.textViewHistory);
        dbHelper = new DatabaseHelper(this);

        loadWeightHistory();

        buttonSubmitWeight.setOnClickListener(view -> {
            String weightInput = editTextWeight.getText().toString().trim();
            if (!weightInput.isEmpty()) {
                dbHelper.insertWeight(currentUsername, weightInput);
                editTextWeight.setText("");
                Toast.makeText(this, "Weight saved", Toast.LENGTH_SHORT).show();
                loadWeightHistory(); // Refresh the list
            } else {
                Toast.makeText(this, "Please enter your weight", Toast.LENGTH_SHORT).show();
            }
        });

        // Setup bottom navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_weight);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, LoginActivity.class));
                return true;
            } else if (id == R.id.nav_weight) {
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void loadWeightHistory() {
        List<String> weights = dbHelper.getAllWeights(currentUsername);
        StringBuilder builder = new StringBuilder();
        for (String weight : weights) {
            builder.append(weight).append("\n");
        }
        textViewHistory.setText(builder.toString());
    }
}
