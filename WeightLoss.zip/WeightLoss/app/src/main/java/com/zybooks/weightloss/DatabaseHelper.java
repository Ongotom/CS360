package com.zybooks.weightloss;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "UserDB.db";
    public static final String TABLE_NAME = "users";
    public static final String COL_ID = "ID";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    public static final String TABLE_WEIGHT = "weights";
    public static final String COL_WEIGHT_ID = "weight_id";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_WEIGHT = "weight";
    public static final String COL_TIMESTAMP = "timestamp";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(query);

        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_ID + " INTEGER, " +
                COL_WEIGHT + " REAL, " +
                COL_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP)";
        db.execSQL(createWeightTable);

        // Optional: Add default user
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, "admin");
        values.put(COL_PASSWORD, "1234");
        db.insert(TABLE_NAME, null, values);
    }
    // Insert a new weight for a user
    public void insertWeight(String userId, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_ID, userId);
        values.put(COL_WEIGHT, weight);
        db.insert(TABLE_WEIGHT, null, values);
    }

    // Get all weights for a user
    public Cursor getUserWeights(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " WHERE " + COL_USER_ID + "=? ORDER BY " + COL_TIMESTAMP + " DESC",
                new String[]{String.valueOf(userId)});
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // ✅ Check if username/password match (used for login)
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                new String[]{COL_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // ✅ Check if a username already exists (used for registration)
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                new String[]{COL_ID},
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }
//    public int getUserId(String username) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.query("users", new String[]{"ID"},
//                "username = ?", new String[]{username},
//                null, null, null);
//
//        int userId = -1;
//        if (cursor.moveToFirst()) {
//            userId = cursor.getInt(cursor.getColumnIndexOrThrow("ID"));
//        }
//        cursor.close();
//        return userId;
//    }


    // ✅ Register a new user if username doesn't already exist
    public boolean insertUser(String username, String password) {
        if (userExists(username)) return false;

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public List<String> getAllWeights(String currentUsername) {
        return java.util.Collections.emptyList();
    }
}